# -*- coding: utf-8 -*-
## @package som_cm.cv
#
#  OpenCV modules.
#  @author      tody
#  @date        2015/07/31

